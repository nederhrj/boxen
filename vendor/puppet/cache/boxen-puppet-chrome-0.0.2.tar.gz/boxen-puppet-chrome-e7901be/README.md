# Chrome Puppet Module for Boxen

Requires the `boxen` puppet module.

## Usage

```puppet
# Chrome from stable channel
include chrome

# Chrome from dev channel
include chrome::dev
```

## Developing

Write code.

Run `script/cibuild`.
