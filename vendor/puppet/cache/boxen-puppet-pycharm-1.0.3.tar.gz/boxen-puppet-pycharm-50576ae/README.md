# PyCharm

[![Build Status](https://travis-ci.org/boxen/puppet-pycharm.png?branch=master)](https://travis-ci.org/boxen/puppet-pycharm)

## Usage

```puppet
include pycharm
```

## Required Puppet Modules

* `boxen`

