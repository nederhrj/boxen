# iStat Menus 3 Puppet Module for Boxen

## Usage

```puppet
include istatmenus3 
```

## Required Puppet Modules

* boxen
* stdlib

## Developing

Write code.

Run `script/cibuild`.
